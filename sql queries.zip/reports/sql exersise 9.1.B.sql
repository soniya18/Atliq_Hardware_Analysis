DROP TEMPORARY TABLE IF EXISTS forcast_err_2021;
CREATE TEMPORARY TABLE forcast_err_2021
WITH forecast_err_table AS (
	SELECT
       fiscal_year,
	   customer_code,
	   ROUND(SUM(ABS(forecast_quantity - sold_quantity)*100)/ SUM(forecast_quantity), 2) AS abs_error_pct
	FROM gdb0041.fact_act_est
    WHERE fiscal_year = 2021
	GROUP BY customer_code
)
SELECT 
		c.customer_code,
        c.customer,
		c.market ,
		IF(abs_error_pct > 100, 0, 100 - abs_error_pct) AS forecast_accuracy_2021
FROM forecast_err_table a
JOIN dim_customer c
USING (customer_code);

SELECT * FROM forcast_err_2021;