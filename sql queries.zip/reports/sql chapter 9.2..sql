SELECT * FROM gdb0041.fact_act_est;

SET SQL_SAFE_UPDATES = 0;

UPDATE fact_act_est
SET sold_quantity = 0
WHERE sold_quantity IS NULL;

UPDATE fact_act_est
SET forecast_quantity = 0
WHERE forecast_quantity IS NULL;