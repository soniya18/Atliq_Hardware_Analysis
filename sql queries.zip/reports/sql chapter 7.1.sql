-- herarchy = division -> segment -> category -> product -> variant
-- Croma - 90002002
-- Month
-- product name
-- variant
-- sold qty
-- gross price per item
-- gross price total


-- SELECT * FROM dim_customer WHERE customer = "Croma";

SELECT
      s.date,
      s.product_code,
	  p.product,
	  p.variant,
      s.sold_quantity,
      g.gross_price,
      ROUND(g.gross_price * s.sold_quantity, 2) AS  gross_price_total
FROM fact_sales_monthly s
JOIN dim_product p
ON p.product_code = s.product_code
JOIN fact_gross_price g
ON 
  g.product_code = s.product_code AND 
  g.fiscal_year = get_FY(s.date)
WHERE customer_code = 90002002 AND
      get_FY(date) = 2021
ORDER BY date
limit 10000;

-- YEAR(DATE_ADD("2020-09-01", INTERVAL 4 MONTH)) this will give us the fiscal year sep-aug
-- created function
-- SELECT get_fiscal_year("2020-09-01");

-- MONTH("2020-08-01") used to get the month out of the date
-- 9,10,11 -- Q1
-- 12,1,2 -- Q2
-- 3,4,5 -- Q3
-- 6,7,8 -- Q4
-- select gdb0041.get_fiscal_quarter('2020-09-01') AS QTR;