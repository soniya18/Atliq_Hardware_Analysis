SELECT 
        a.customer_code,
        a.customer,
		a.market,
        a.forecast_accuracy_2020,
        b.forecast_accuracy_2021
FROM forcast_err_2020 a
JOIN forcast_err_2021 b
USING (customer_code, customer, market)
