-- CREATE TRIGGERS
-- 1

DROP TRIGGER IF EXISTS `gdb0041`.`fact_act_est_AFTER_INSERT`;

DELIMITER $$
USE `gdb0041`$$
CREATE DEFINER = CURRENT_USER TRIGGER `gdb0041`.`fact_act_est_AFTER_INSERT` AFTER INSERT ON `fact_act_est` FOR EACH ROW
BEGIN
     INSERT INTO fact_act_est
     (date, product_code, customer_code, sold_quantity)
     VALUES (
          NEW.date, 
          NEW.product_code, 
          NEW.customer_code, 
          NEW.sold_quantity
      )
     on duplicate key update
        sold_quantity = VALUES(sold_quantity);
END$$
DELIMITER ;


-- 2

DROP TRIGGER IF EXISTS `gdb0041`.`fact_forecast_monthly_AFTER_INSERT`;

DELIMITER $$
USE `gdb0041`$$
CREATE DEFINER=`root`@`localhost` TRIGGER `fact_forecast_monthly_AFTER_INSERT` AFTER INSERT ON `fact_forecast_monthly` FOR EACH ROW BEGIN
     INSERT INTO fact_act_est
     (date, product_code, customer_code, forecast_quantity)
     VALUES (
          NEW.date, 
          NEW.product_code, 
          NEW.customer_code, 
          NEW.forecast_quantity
      )
     on duplicate key update
        forecast_quantity = VALUES(forecast_quantity);
END$$
DELIMITER ;

SHOW TRIGGERS