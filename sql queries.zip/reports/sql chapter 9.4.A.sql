-- supply chain report task 8
-- use of cte
WITH CTE1 AS (
	SELECT
	   customer_code,
	   SUM(sold_quantity) AS total_sold_qty,
	   SUM(forecast_quantity) AS total_forecast_qty,
	   SUM(forecast_quantity - sold_quantity) AS net_error,
	   ROUND(SUM((forecast_quantity - sold_quantity)*100)/ SUM(forecast_quantity), 2) AS net_error_pct,
	   SUM(ABS(forecast_quantity - sold_quantity)) AS abs_error,
	   ROUND(SUM(ABS(forecast_quantity - sold_quantity)*100)/ SUM(forecast_quantity), 2) AS abs_error_pct
	FROM gdb0041.fact_act_est
	WHERE fiscal_year = 2021
	GROUP BY customer_code
)
	SELECT 
		c.customer,
		c.market ,
		a.total_sold_qty,
		a.total_forecast_qty,
		a.net_error,
		a.net_error_pct,
		a.abs_error,
		a.abs_error_pct,
		IF(abs_error_pct > 100, 0, 100 - abs_error_pct) AS forecast_accuracy
	FROM CTE1 a
	JOIN dim_customer c
	USING (customer_code)
	ORDER BY forecast_accuracy DESC;