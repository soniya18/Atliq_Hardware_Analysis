-- TASK 7
-- TOP 2 PRODUCT BY SOLD QTY


WITH CTE1 AS (
SELECT 
      p.division, 
      p.product,
      SUM(s.sold_quantity) AS total_qty
FROM fact_sales_monthly s
JOIN dim_product p
ON p.product_code = s.product_code
WHERE fiscal_year = 2021
GROUP BY p.product, p.division),

CTE2 AS (
SELECT 
    *,
    DENSE_RANK() OVER(partition by division order by total_qty DESC) AS drnk
FROM CTE1)

SELECT * FROM CTE2
WHERE drnk <= 3
ORDER BY division;


-- created stored procedure get_top_n_products_per_dividion_by_qty_sold
USE `gdb0041`;
DROP procedure IF EXISTS `get_top_n_products_per_division_by_qty_sold`;

DELIMITER $$
USE `gdb0041`$$
CREATE PROCEDURE `get_top_n_products_per_division_by_qty_sold`(
        	in_fiscal_year INT,
    		in_top_n INT
	)
	BEGIN
	     with cte1 as (
		   select
                       p.division,
                       p.product,
                       sum(sold_quantity) as total_qty
                   from fact_sales_monthly s
                   join dim_product p
                       on p.product_code=s.product_code
                   where fiscal_year=in_fiscal_year
                   group by p.product),            
             cte2 as (
		   select 
                        *,
                        dense_rank() over (partition by division order by total_qty desc) as drnk
                   from cte1)
	     select * from cte2 where drnk <= in_top_n;
	END$$

DELIMITER ;






