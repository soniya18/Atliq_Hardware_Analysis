-- TOP 5 MARKETS

SELECT 
market,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales
WHERE fiscal_year = 2021
GROUP BY market
ORDER BY net_sales_mln DESC
LIMIT 5;

-- TOP 5 CUSTOMERS

SELECT 
c.customer,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales ns
JOIN dim_customer c
ON ns.customer_code = c.customer_code
WHERE fiscal_year = 2021
GROUP BY customer
ORDER BY net_sales_mln DESC
LIMIT 5;

-- TOP 5 PRODUCTS

SELECT 
product,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales
WHERE fiscal_year = 2021
GROUP BY product
ORDER BY net_sales_mln DESC
LIMIT 5;

-- This may repeated so created stored procedure for each of them
-- top market
USE `gdb0041`;
DROP procedure IF EXISTS `get_top_n_markets_by_fiscal_year`;

USE `gdb0041`;
DROP procedure IF EXISTS `gdb0041`.`get_top_n_markets_by_fiscal_year`;
;

DELIMITER $$
USE `gdb0041`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_top_n_markets_by_fiscal_year`(
		in_fiscal_year TEXT,
        in_top_n INT
)
BEGIN
SELECT 
market,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales
WHERE fiscal_year = in_fiscal_year
GROUP BY market
ORDER BY net_sales_mln DESC
LIMIT in_top_n;
END$$

DELIMITER ;
;

-- top customer
USE `gdb0041`;
DROP procedure IF EXISTS `get_top_n_customer_by_fiscal_year`;

DELIMITER $$
USE `gdb0041`$$
CREATE PROCEDURE get_top_n_customer_by_fiscal_year (
        in_market TEXT,
        in_fiscal_year YEAR,
        in_top_n INT
)
BEGIN
SELECT 
c.customer,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales ns
JOIN dim_customer c
ON ns.customer_code = c.customer_code
WHERE fiscal_year = in_fiscal_year AND market = in_market
GROUP BY customer
ORDER BY net_sales_mln DESC
LIMIT in_top_n;
END$$

DELIMITER ;

-- top product
USE `gdb0041`;
DROP procedure IF EXISTS `get_top_n_product_by_fiscal_year`;

USE `gdb0041`;
DROP procedure IF EXISTS `gdb0041`.`get_top_n_product_by_fiscal_year`;
;

DELIMITER $$
USE `gdb0041`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_top_n_product_by_fiscal_year`(
        in_market TEXT,
        in_fiscal_year YEAR,
        in_top_n INT
)
BEGIN
SELECT 
product,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales ns
JOIN dim_customer c
ON ns.customer_code = c.customer_code
WHERE fiscal_year = in_fiscal_year AND market = in_market
GROUP BY product
ORDER BY net_sales_mln DESC
LIMIT in_top_n;
END$$

DELIMITER ;
;


