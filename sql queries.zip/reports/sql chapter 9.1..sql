-- TASK 8 SUPPLY CHAIN ANALYSIS
CREATE TABLE fact_act_est AS
(
	SELECT 
			s.date AS date,
			s.product_code AS product_code,
			s.customer_code AS customer_code,
			s.sold_quantity AS sold_quantity,
			f.forecast_quantity AS forecast_quantity
	FROM fact_sales_monthly s
	LEFT JOIN fact_forecast_monthly f
	USING (date, product_code, customer_code)

	UNION

	SELECT 
			f.date AS date,
			f.product_code AS product_code,
			f.customer_code AS customer_code,
			s.sold_quantity AS sold_quantity,
			f.forecast_quantity AS forecast_quantity
	FROM fact_forecast_monthly f
	LEFT JOIN fact_sales_monthly s
	USING (date, product_code, customer_code)
);
