	-- TASK 4
-- performance improvement 1
-- create dim_date table with date anf FY as generated col

SELECT
      s.date,
      s.product_code,
	  p.product,
	  p.variant,
      s.sold_quantity,
      g.gross_price AS gross_price_per_item,
      ROUND(g.gross_price * s.sold_quantity, 2) AS  gross_price_total,
      pre.pre_invoice_discount_pct
FROM fact_sales_monthly s
JOIN dim_product p
ON p.product_code = s.product_code
JOIN dim_date dt
ON dt.calendar_date = s.date
JOIN fact_gross_price g
ON 
  g.product_code = s.product_code AND 
  g.fiscal_year = dt.fiscal_year
JOIN fact_pre_invoice_deductions pre
ON 
  pre.customer_code = s.customer_code AND
  pre.fiscal_year = dt.fiscal_year 
WHERE dt.fiscal_year = 2021
ORDER BY s.date
LIMIT 1000000;