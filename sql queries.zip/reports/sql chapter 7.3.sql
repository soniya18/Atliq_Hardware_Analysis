-- CREATE A STORED PROCEDURE FOR THIS
-- INDIA, 2020 --> GOLD
-- SRILANKA, 2021 --> SILVER
-- MARKET - INPUT
-- FISCAL YEAR - INPUT
-- MAKET BADGE -- OUTPUT

SELECT 
   SUM(m.sold_quantity) AS total_qty
FROM fact_sales_monthly m
JOIN dim_customer c
ON c.customer_code = m.customer_code
WHERE get_FY(m.date) = 2021 AND c.market = "india"
GROUP BY c.market;

-- creation of stored procedure 2
USE `gdb0041`;
DROP procedure IF EXISTS `get_market_badge`;

DELIMITER $$
USE `gdb0041`$$
CREATE PROCEDURE `get_market_badge`(
        	IN in_market VARCHAR(45),
        	IN in_fiscal_year YEAR,
        	OUT out_level VARCHAR(45)
	)
	BEGIN
             DECLARE qty INT DEFAULT 0;
    
    	     # Default market is India
    	     IF in_market = "" THEN
                  SET in_market="India";
             END IF;
    
    	     # Retrieve total sold quantity for a given market in a given year
             SELECT 
                  SUM(s.sold_quantity) INTO qty
             FROM fact_sales_monthly s
             JOIN dim_customer c
             ON s.customer_code=c.customer_code
             WHERE 
                  get_FY(s.date)=in_fiscal_year AND
                  c.market=in_market;
        
             # Determine Gold vs Silver status
             IF qty > 5000000 THEN
                  SET out_level = 'Gold';
             ELSE
                  SET out_level = 'Silver';
             END IF;
	END$$

DELIMITER ;

-- calling of stored procedure 2
set @out_level = '0';
call gdb0041.get_market_badge('india', 2020, @out_level);
select @out_level;

