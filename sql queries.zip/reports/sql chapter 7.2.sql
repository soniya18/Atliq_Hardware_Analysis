-- SELECT * FROM dim_customer WHERE customer = "CROMA"
-- month
-- total gross price


SELECT
   s.date,
   SUM(ROUND(g.gross_price * s.sold_quantity, 2)) as gross_price_total
FROM fact_sales_monthly s
JOIN fact_gross_price g
ON 
  g.product_code = s.product_code AND
  g.fiscal_year = get_FY(s.date)
WHERE 
     customer_code = 90002002
GROUP BY s.date
ORDER BY s.date; 


-- creation of stored procedure 1 

USE `gdb0041`;
DROP procedure IF EXISTS `get_monthly_gross_sales_for_customer`;

DELIMITER $$
USE `gdb0041`$$
CREATE PROCEDURE `get_monthly_gross_sales_for_customer`(
        	in_customer_codes TEXT
	)
	BEGIN
        	SELECT 
                    s.date, 
                    SUM(ROUND(s.sold_quantity*g.gross_price,2)) as monthly_sales
        	FROM fact_sales_monthly s
        	JOIN fact_gross_price g
               	    ON g.fiscal_year=get_fiscal_year(s.date)
                    AND g.product_code=s.product_code
        	WHERE 
                    FIND_IN_SET(s.customer_code, in_customer_codes) > 0
        	GROUP BY s.date
        	ORDER BY s.date DESC;
	END$$

DELIMITER ;