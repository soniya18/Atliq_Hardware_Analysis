-- creation of function thru scripts
-- get fy

USE `gdb0041`;
DROP function IF EXISTS `get_FY`;

DELIMITER $$
USE `gdb0041`$$
CREATE FUNCTION get_FY (
        calendar_date DATE
)
RETURNS INTEGER
deterministic
BEGIN
       DECLARE fiscal_year INT;
       SET fiscal_year = YEAR(DATE_ADD(calendar_date, INTERVAL 4 MONTH));
	   RETURN fiscal_year;
END$$

DELIMITER ;

-- get quarter function

USE `gdb0041`;
DROP function IF EXISTS `get_fiscal_quarter`;

DELIMITER $$
USE `gdb0041`$$
CREATE FUNCTION get_fiscal_quarter (
       calendar_date DATE
)
RETURNS CHAR(2)
deterministic
BEGIN
     DECLARE M TINYINT;
     DECLARE qtr CHAR(2);
     SET M = MONTH(calendar_date);
     
     CASE
         WHEN M IN (9,10,11) THEN SET qtr = "Q1";
         WHEN M IN (12,1,2) THEN SET qtr = "Q2";
         WHEN M IN (3,4,5) THEN SET qtr = "Q3";
         WHEN M IN (6,7,8) THEN SET qtr = "Q4";
     END CASE;
RETURN qtr;
END$$

DELIMITER ;

