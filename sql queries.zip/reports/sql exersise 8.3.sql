-- exersice same as task 7
-- top 2 market by region by gross_sales_mln


WITH CTE1 AS(
SELECT 
     C.market,
     C.region,
     ROUND(SUM((S.sold_quantity * G.gross_price)/1000000), 2) AS gross_sales_mln
FROM fact_sales_monthly S
JOIN dim_customer C
ON C.customer_code = S.customer_code
JOIN fact_gross_price G
ON 
  G.product_code = S.product_code AND
  G.fiscal_year = S.fiscal_year
  WHERE S.fiscal_year = 2021
GROUP BY market, region
),
 
 CTE2 AS (
SELECT *,
DENSE_RANK() OVER(PARTITION BY region ORDER BY gross_sales_mln DESC) AS drnk
FROM CTE1
GROUP BY market, region
ORDER BY region)

SELECT * FROM CTE2 WHERE drnk <= 2;