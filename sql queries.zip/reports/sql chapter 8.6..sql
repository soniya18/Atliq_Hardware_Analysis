-- using windows function in our task 5
--  net sales global market share % in 2021

WITH CTE1 AS
(
SELECT 
c.customer,
ROUND(SUM(net_sales)/1000000, 2) AS net_sales_mln
FROM net_sales ns
JOIN dim_customer c
ON ns.customer_code = c.customer_code
WHERE fiscal_year = 2021
GROUP BY customer)
SELECT 
*,
net_sales_mln*100/SUM(net_sales_mln) OVER() AS pct
FROM CTE1
ORDER BY net_sales_mln DESC;